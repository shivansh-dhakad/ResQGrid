    // ─── TAILWIND CONFIG (ResQGrid design tokens) ──────────────────────────────────
    // Loaded via the Tailwind CDN script before any markup is rendered, so the
    // custom utility classes used throughout the templates (text-on-surface,
    // bg-surface-container-low, text-headline-md, px-page-margin, etc.) resolve.
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: "#0097a7",
            "primary-container": "#c8eef2",
            surface: "#ffffff",
            "surface-container-low": "#eef3f7",
            "on-surface": "#0d1f2d",
            "on-surface-variant": "#6b8a96",
            "text-muted": "#6b8a96",
            "border-base": "#c8dde8",
            secondary: "#6b8a96",
            danger: "#ef4444",
          },
          fontSize: {
            "headline-lg": ["26px", { fontWeight: "800", lineHeight: "1.2" }],
            "headline-md": ["20px", { fontWeight: "700", lineHeight: "1.25" }],
            "headline-sm": ["16px", { fontWeight: "700", lineHeight: "1.3" }],
            "body-lg": ["15px", { fontWeight: "600", lineHeight: "1.4" }],
            "body-md": ["13px", { fontWeight: "500", lineHeight: "1.45" }],
            "body-sm": ["12px", { fontWeight: "500", lineHeight: "1.45" }],
            "label-sm": ["10px", { fontWeight: "700", lineHeight: "1.3", letterSpacing: "0.08em" }],
          },
          spacing: {
            "page-margin": "16px",
            "touch-target": "60px",
          },
          fontFamily: {
            sans: ["Sora", "sans-serif"],
            mono: ["JetBrains Mono", "monospace"],
          },
        },
      },
    };
