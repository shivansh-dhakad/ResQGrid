      // ─── UI HELPERS ──────────────────────────────────────────────────────────────
      // Toast notifications, modal stubs, and small render helpers used by the
      // dashboard. Kept separate from core.js / dashboard.js so those files can
      // stay focused on session + data logic.

      const RESOURCE_RADIUS_KM = 50;
      const COMMUNITY_RADIUS_KM = 50;

      // Sets/lists used by notification bookkeeping (kept simple — full
      // notification panel isn't part of this build).
      let _knownAlertIds = new Set();
      let _knownResourceIds = new Set();
      let _knownSosIds = new Set();
      let _notifList = [];
      function _renderNotifList() {
        /* no-op: notification panel UI not included in this build */
      }
      function startNotifPolling() {
        /* no-op: polling not enabled in this build */
      }
      function stopNotifPolling() {
        /* no-op */
      }
      function loadProfileStats() {
        /* Profile stats are populated directly from the login payload in
           enterApp(); nothing extra to fetch here. */
      }

      // ─── TOAST ───────────────────────────────────────────────────────────────────
      function showToast(message, type = "info") {
        const toast = document.getElementById("toast");
        if (!toast) return;
        toast.textContent = message;
        toast.className = `toast show ${type}`;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
          toast.classList.remove("show");
        }, 3000);
      }

      // ─── MODALS / NOTIFICATIONS (stubs for header buttons) ─────────────────────────
      function openModal(id) {
        const el = document.getElementById(id);
        if (el) {
          el.classList.add("show");
          return;
        }
        showToast("This feature is coming soon", "info");
      }
      function closeModal(id) {
        const el = document.getElementById(id);
        if (el) el.classList.remove("show");
      }
      function toggleNotif() {
        const panel = document.getElementById("notif-panel");
        if (panel) {
          panel.classList.toggle("show");
          return;
        }
        showToast("No new notifications", "info");
      }

      // ─── CARD RENDER HELPERS ────────────────────────────────────────────────────
      function alertCardHTML(a) {
        const risk = a.risk_level || "medium";
        return `
          <div class="p-4 bg-white rounded-lg border border-border-base flex flex-col gap-1.5">
            <div class="flex items-center justify-between gap-2">
              <span class="px-2 py-0.5 rounded-full text-label-sm font-bold uppercase ${getRiskBg(risk)}">${risk}</span>
              <span class="text-label-sm text-text-muted">${formatTimeAgo(a.created_at)}</span>
            </div>
            <p class="text-body-md font-bold text-on-surface">${a.title || "Emergency"}</p>
            <p class="text-body-sm text-text-muted">${a.description || ""}</p>
          </div>`;
      }

      function resourceCardHTML(r) {
        return `
          <div class="p-4 bg-white rounded-lg border border-border-base flex flex-col gap-1.5">
            <div class="flex items-center justify-between gap-2">
              <span class="px-2 py-0.5 rounded-full text-label-sm font-bold uppercase bg-slate-100 text-slate-600">${r.category || "resource"}</span>
              <span class="text-label-sm text-text-muted">${formatTimeAgo(r.created_at)}</span>
            </div>
            <p class="text-body-md font-bold text-on-surface">${r.title || r.name || "Resource"}</p>
            <p class="text-body-sm text-text-muted">${r.description || ""}</p>
          </div>`;
      }
