"""
routes/grid.py — Dashboard data endpoints (emergencies, resources,
communities, leaderboard).

This is a minimal implementation that returns real data from Supabase when
the relevant tables exist, and falls back to an empty list otherwise so the
dashboard always renders cleanly instead of throwing 404s.
"""

import logging

from flask import Blueprint, request
from utils import success, sb_get

log = logging.getLogger(__name__)
grid_bp = Blueprint("grid", __name__, url_prefix="/api")


def _safe_sb_get(table, params=""):
    try:
        return sb_get(table, params, service=True)
    except Exception as e:
        log.warning(f"grid: could not read '{table}': {e}")
        return []


@grid_bp.route("/emergencies", methods=["GET"])
def list_emergencies():
    return success(_safe_sb_get("emergencies", "select=*&order=created_at.desc"))


@grid_bp.route("/resources", methods=["GET"])
def list_resources():
    return success(_safe_sb_get("resources", "select=*&order=created_at.desc"))


@grid_bp.route("/communities", methods=["GET"])
def list_communities():
    return success(_safe_sb_get("communities", "select=*&order=created_at.desc"))


@grid_bp.route("/communities/memberships", methods=["GET"])
def community_memberships():
    user_id = request.args.get("user_id", "")
    if not user_id:
        return success({})
    rows = _safe_sb_get(
        "community_members",
        f"user_id=eq.{user_id}&select=ngo_id,status",
    )
    return success({row["ngo_id"]: row["status"] for row in rows})


@grid_bp.route("/leaderboard", methods=["GET"])
def leaderboard():
    return success(_safe_sb_get("users", "select=id,full_name,display_name,score,badge&order=score.desc&limit=20"))
