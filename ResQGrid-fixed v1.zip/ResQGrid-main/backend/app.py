"""
app.py — ResQGrid Flask entry point.

This file is intentionally thin: it only sets up the Flask app, loads
environment config, wires the route blueprints, and starts the server.

Route logic lives in:
  routes/auth.py       — signup & login
  routes/grid.py       — emergencies, resources, communities, leaderboard

Shared utilities (Supabase helpers, geo functions, stat bumps) are in:
  utils.py
"""

import os
import logging

from flask import Flask, render_template, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

# ── Environment ───────────────────────────────────────────────────────────────
load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))

# ── App setup ─────────────────────────────────────────────────────────────────
BASE_DIR     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR   = os.path.join(BASE_DIR, 'static')

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)
CORS(app, resources={r"/api/*": {"origins": os.getenv("ALLOWED_ORIGINS", "*")}})

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s %(message)s')
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
SUPABASE_URL  = os.getenv("SUPABASE_URL", "")
SUPABASE_ANON = os.getenv("SUPABASE_ANON_KEY", "")
SUPABASE_SVC  = os.getenv("SUPABASE_SERVICE_KEY", "")
PORT          = int(os.getenv("PORT", 5000))
DEBUG         = os.getenv("FLASK_DEBUG", "false").lower() == "true"

# ── Wire up shared utilities ──────────────────────────────────────────────────
import utils
utils.init_config(SUPABASE_URL, SUPABASE_ANON, SUPABASE_SVC)

# ── Register blueprints ───────────────────────────────────────────────────────
from routes.auth import auth_bp
from routes.grid import grid_bp

app.register_blueprint(auth_bp)
app.register_blueprint(grid_bp)

# ── Frontend routes ───────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(STATIC_DIR, filename)

# ── Health check ──────────────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    from utils import success
    return success({
        "status":   "ok",
        "service":  "ResQGrid API",
        "version":  "1.0.0",
        "supabase": bool(SUPABASE_URL),
    })


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    log.info(f"ResQGrid starting on port {PORT} | debug={DEBUG}")
    app.run(host="0.0.0.0", port=PORT, debug=DEBUG)